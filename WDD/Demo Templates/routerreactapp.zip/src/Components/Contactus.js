import React from 'react'

export const Contactus = () => {
    return (
        <React.Fragment>
            <h2>Contact us Page</h2><br />
            <p>This is the contact us page of site</p>
        </React.Fragment>
    )
}
